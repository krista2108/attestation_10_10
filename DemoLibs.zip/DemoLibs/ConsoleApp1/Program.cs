﻿using System;
using System.Collections.Generic;
using System.Linq;
using DemoLibs;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	internal class Program

	{
		static void Main(string[] args)
		{
			Work work = new Work();	

			Random rand = new Random();	
			List<Work.Student> students = new List<Work.Student>()
			{
				new Work.Student("Калугина Кристина Николаевна", 818, 2018),
				new Work.Student("Нагорный Данила Алексеевич", 818, 2018)
			};
			Console.WriteLine("Студенты ");
			foreach (var stud in students)
			{
				stud.PrintInfo();
			}			
			List<Work.Mark> mark = work.GetMarks(DateTime.Now, students);
			// Задание 1.		
			Console.WriteLine();
			Console.WriteLine("Задание 1.");
			List<Work.Mark> marR = work.GetMarks(DateTime.Today, students);
			marR.AddRange(work.GetMarks(DateTime.Parse("01.04.2022"), students));
			marR.AddRange(work.GetMarks(DateTime.Parse("01.05.2022"), students));
			for (int i = 0; i < marR.Count; i++)
            {
				Console.WriteLine(marR[i].Attendance + ": " + marR[i].Estimation);
            }

			//Задание 2. 
			Console.WriteLine();
			Console.WriteLine("Задание 2.");
			string[] atend = new string[] {"5", "5", "3", "4", "2" };
			Console.Write("Оценки: ");
			foreach (var at in atend)
            {
				Console.Write(at + ", ");
            }
			Console.WriteLine("Сред. балл: " + work.MinAVG(atend));
		
			//Задание 5.  
			Console.WriteLine();
			Console.WriteLine("Задание 5.");

			for (int i = 0; i < students.Count; i++)
			{
				Console.WriteLine(work.GetStudNumber(students[i].Year, students[i].Group, students[i].FIO));
			}

			Console.ReadKey();
		}
	}
}
